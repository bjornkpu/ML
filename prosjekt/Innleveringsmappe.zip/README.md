Installering:

For dependencies: 'pip install gym tensorflow tf-agents-nightly tfp-nightly imageio pybullet'

For trening av miljø: 'python train_eval.py --sfx=navnher'
checkpoints havner i undermappen ./checkpoints/
For hjelp: 'python train_eval.py --help'
For rendering av ferdig trent modell:
'python RenderAnt --sfx=navnher --policy_nr=1500'
